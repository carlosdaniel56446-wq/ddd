# Deploy na Vercel — Passa Fácil

## Opção 1: GitHub (recomendado)

1. Crie um repositório no GitHub
2. Extraia o ZIP e envie os arquivos **na raiz do repositório** (não dentro de uma pasta passa-facil/)
3. Em vercel.com → New Project → Import do GitHub
4. Framework: Next.js (detectado automaticamente)
5. Deploy

## Opção 2: Upload direto

1. Extraia o ZIP
2. Na Vercel: New Project → "Upload" / CLI
3. Ou use: `npx vercel` na pasta do projeto

## Estrutura correta na raiz

```
package.json
next.config.ts
tsconfig.json
tailwind.config.ts
postcss.config.mjs
src/
  app/
  components/
  lib/
  store/
  types/
```

**Importante:** o `package.json` precisa estar na raiz do projeto na Vercel, não dentro de subpasta.

## Comandos locais

```bash
npm install
npm run dev
npm run build   # deve concluir sem erro
```

## Se der erro

Copie a mensagem completa da aba "Build Logs" na Vercel e envie.
