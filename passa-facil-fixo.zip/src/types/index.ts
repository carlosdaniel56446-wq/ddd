export type StudyProfile =
  | "fundamental"
  | "medio"
  | "enem"
  | "superior"
  | "tecnico"
  | "concurso"
  | "outro";

export type MaterialStatus =
  | "uploading"
  | "processing"
  | "analyzed"
  | "ready"
  | "error";

export type Difficulty = "facil" | "medio" | "dificil";

export interface UserProfile {
  name: string;
  profile: StudyProfile;
  theme: "light" | "dark" | "system";
  createdAt: string;
  examDate?: string;
  dailyMinutes?: number;
}

export interface Material {
  id: string;
  title: string;
  subject?: string;
  topics: string[];
  originalText: string;
  fileName?: string;
  fileType?: string;
  status: MaterialStatus;
  errorMessage?: string;
  createdAt: string;
  updatedAt: string;
  analysis?: MaterialAnalysis;
}

export interface MaterialAnalysis {
  mainSubject: string;
  suggestedSubject: string;
  topics: string[];
  keyConcepts: string[];
  definitions: { term: string; definition: string }[];
  formulas: string[];
  difficulty: Difficulty;
  summary: string;
  structure: string[];
}

export interface Summary {
  id: string;
  materialId: string;
  title: string;
  quickSummary: string;
  fullSummary: string;
  topics: string[];
  keyConcepts: string[];
  definitions: { term: string; definition: string }[];
  formulas: string[];
  toMemorize: string[];
  glossary: { term: string; definition: string }[];
  createdAt: string;
}

export interface Flashcard {
  id: string;
  materialId: string;
  question: string;
  answer: string;
  difficulty: Difficulty;
  needsReview: boolean;
  timesReviewed: number;
  timesCorrect: number;
  timesIncorrect: number;
  lastReviewed?: string;
  nextReview?: string;
  createdAt: string;
}

export interface Question {
  id: string;
  materialId: string;
  type: "multiple" | "truefalse" | "open";
  question: string;
  options?: string[];
  correctAnswer: string | boolean;
  explanation: string;
  commonMistakes?: string;
  topic?: string;
  difficulty: Difficulty;
}

export interface QuizAttempt {
  id: string;
  materialId: string;
  questions: Question[];
  answers: Record<string, string | boolean>;
  score: number;
  total: number;
  completedAt: string;
  timeSpentSeconds?: number;
}

export interface StudyPlanSession {
  id: string;
  date: string;
  title: string;
  subject?: string;
  type: "estudo" | "exercicio" | "revisao";
  durationMinutes: number;
  completed: boolean;
  postponed: boolean;
  materialId?: string;
}

export interface StudyPlan {
  id: string;
  title: string;
  examDate?: string;
  dailyMinutes: number;
  subjects: string[];
  sessions: StudyPlanSession[];
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  materialId?: string;
}

export interface Conversation {
  id: string;
  title: string;
  materialId?: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface ProgressStats {
  totalMaterials: number;
  totalQuestionsAnswered: number;
  totalCorrect: number;
  accuracy: number;
  bySubject: Record<string, { answered: number; correct: number }>;
  studyStreak: number;
  lastStudyDate?: string;
  weakTopics: string[];
}

export interface AppState {
  user: UserProfile | null;
  materials: Material[];
  summaries: Summary[];
  flashcards: Flashcard[];
  questions: Question[];
  attempts: QuizAttempt[];
  plans: StudyPlan[];
  conversations: Conversation[];
  isOnboarded: boolean;
}
