"use client";

import React, { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import type {
  UserProfile,
  Material,
  Summary,
  Flashcard,
  Question,
  QuizAttempt,
  StudyPlan,
  Conversation,
  ChatMessage,
  StudyProfile,
} from "@/types";
import { generateId } from "@/lib/utils";
import {
  analyzeMaterial,
  generateSummary,
  generateFlashcards,
  generateQuestions,
  chatResponse,
} from "@/lib/ai-local";

interface AppContextValue {
  user: UserProfile | null;
  isOnboarded: boolean;
  materials: Material[];
  summaries: Summary[];
  flashcards: Flashcard[];
  questions: Question[];
  attempts: QuizAttempt[];
  plans: StudyPlan[];
  conversations: Conversation[];
  activeConversationId: string | null;
  completeOnboarding: (name: string, profile: StudyProfile) => void;
  updateUser: (p: Partial<UserProfile>) => void;
  addMaterial: (d: { title: string; originalText: string; fileName?: string; fileType?: string }) => string;
  updateMaterial: (id: string, p: Partial<Material>) => void;
  deleteMaterial: (id: string) => void;
  processMaterial: (id: string) => void;
  prepareStudyPackage: (id: string) => void;
  updateFlashcard: (id: string, p: Partial<Flashcard>) => void;
  addAttempt: (a: QuizAttempt) => void;
  addPlan: (p: StudyPlan) => void;
  updatePlan: (id: string, p: Partial<StudyPlan>) => void;
  createConversation: (title?: string, materialId?: string) => string;
  sendChatMessage: (conversationId: string, content: string, materialId?: string) => void;
  setActiveConversation: (id: string | null) => void;
  getStats: () => {
    totalMaterials: number;
    totalQuestionsAnswered: number;
    totalCorrect: number;
    accuracy: number;
    weakTopics: string[];
    studyStreak: number;
  };
  clearAllData: () => void;
  ready: boolean;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_KEY = "passa-facil-storage";

export function AppProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isOnboarded, setIsOnboarded] = useState(false);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [summaries, setSummaries] = useState<Summary[]>([]);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [plans, setPlans] = useState<StudyPlan[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);

  // Load
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (data.user) setUser(data.user);
        if (data.isOnboarded) setIsOnboarded(data.isOnboarded);
        if (data.materials) setMaterials(data.materials);
        if (data.summaries) setSummaries(data.summaries);
        if (data.flashcards) setFlashcards(data.flashcards);
        if (data.questions) setQuestions(data.questions);
        if (data.attempts) setAttempts(data.attempts);
        if (data.plans) setPlans(data.plans);
        if (data.conversations) setConversations(data.conversations);
      }
    } catch {}
    setReady(true);
  }, []);

  // Persist
  useEffect(() => {
    if (!ready) return;
    const data = {
      user,
      isOnboarded,
      materials,
      summaries,
      flashcards,
      questions,
      attempts,
      plans,
      conversations,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [ready, user, isOnboarded, materials, summaries, flashcards, questions, attempts, plans, conversations]);

  const completeOnboarding = (name: string, profile: StudyProfile) => {
    setUser({
      name,
      profile,
      theme: "system",
      createdAt: new Date().toISOString(),
    });
    setIsOnboarded(true);
  };

  const updateUser = (p: Partial<UserProfile>) => {
    setUser((u) => (u ? { ...u, ...p } : null));
  };

  const processMaterial = useCallback((id: string) => {
    setMaterials((prev) => {
      const m = prev.find((x) => x.id === id);
      if (!m || !m.originalText.trim()) {
        return prev.map((x) =>
          x.id === id
            ? {
                ...x,
                status: "error" as const,
                errorMessage: "Texto vazio ou ilegível.",
              }
            : x
        );
      }
      try {
        const analysis = analyzeMaterial(m.originalText, m.title);
        return prev.map((x) =>
          x.id === id
            ? {
                ...x,
                status: "analyzed" as const,
                subject: analysis.suggestedSubject,
                topics: analysis.topics,
                analysis,
                updatedAt: new Date().toISOString(),
              }
            : x
        );
      } catch {
        return prev.map((x) =>
          x.id === id
            ? { ...x, status: "error" as const, errorMessage: "Falha na análise." }
            : x
        );
      }
    });
  }, []);

  const addMaterial = (d: {
    title: string;
    originalText: string;
    fileName?: string;
    fileType?: string;
  }) => {
    const id = generateId();
    const material: Material = {
      id,
      title: d.title || d.fileName || "Material sem título",
      originalText: d.originalText,
      fileName: d.fileName,
      fileType: d.fileType,
      topics: [],
      status: "processing",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setMaterials((prev) => [material, ...prev]);
    setTimeout(() => processMaterial(id), 200);
    return id;
  };

  const updateMaterial = (id: string, p: Partial<Material>) => {
    setMaterials((prev) =>
      prev.map((m) =>
        m.id === id ? { ...m, ...p, updatedAt: new Date().toISOString() } : m
      )
    );
  };

  const deleteMaterial = (id: string) => {
    setMaterials((prev) => prev.filter((m) => m.id !== id));
    setSummaries((prev) => prev.filter((s) => s.materialId !== id));
    setFlashcards((prev) => prev.filter((f) => f.materialId !== id));
    setQuestions((prev) => prev.filter((q) => q.materialId !== id));
  };

  const prepareStudyPackage = (id: string) => {
    setMaterials((prev) => {
      const material = prev.find((m) => m.id === id);
      if (!material?.analysis) return prev;
      const summary = generateSummary(
        id,
        material.originalText,
        material.analysis,
        material.title
      );
      const cards = generateFlashcards(
        id,
        material.analysis,
        material.originalText
      );
      const qs = generateQuestions(
        id,
        material.analysis,
        material.originalText,
        10
      );
      setSummaries((s) => [summary, ...s.filter((x) => x.materialId !== id)]);
      setFlashcards((f) => [...cards, ...f.filter((x) => x.materialId !== id)]);
      setQuestions((q) => [...qs, ...q.filter((x) => x.materialId !== id)]);
      return prev.map((m) =>
        m.id === id ? { ...m, status: "ready" as const, updatedAt: new Date().toISOString() } : m
      );
    });
  };

  const updateFlashcard = (id: string, p: Partial<Flashcard>) => {
    setFlashcards((prev) =>
      prev.map((f) => (f.id === id ? { ...f, ...p } : f))
    );
  };

  const addAttempt = (a: QuizAttempt) => {
    setAttempts((prev) => [a, ...prev]);
  };

  const addPlan = (p: StudyPlan) => {
    setPlans((prev) => [p, ...prev]);
  };

  const updatePlan = (id: string, p: Partial<StudyPlan>) => {
    setPlans((prev) =>
      prev.map((pl) =>
        pl.id === id
          ? { ...pl, ...p, updatedAt: new Date().toISOString() }
          : pl
      )
    );
  };

  const createConversation = (title = "Nova conversa", materialId?: string) => {
    const id = generateId();
    const conv: Conversation = {
      id,
      title,
      materialId,
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setConversations((prev) => [conv, ...prev]);
    setActiveConversationId(id);
    return id;
  };

  const sendChatMessage = (
    conversationId: string,
    content: string,
    materialId?: string
  ) => {
    const userMsg: ChatMessage = {
      id: generateId(),
      role: "user",
      content,
      timestamp: new Date().toISOString(),
    };
    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              messages: [...c.messages, userMsg],
              updatedAt: new Date().toISOString(),
            }
          : c
      )
    );
    const material = materialId
      ? materials.find((m) => m.id === materialId)
      : undefined;
    const reply = chatResponse(
      content,
      material?.originalText,
      material?.analysis
    );
    setTimeout(() => {
      const botMsg: ChatMessage = {
        id: generateId(),
        role: "assistant",
        content: reply,
        timestamp: new Date().toISOString(),
      };
      setConversations((prev) =>
        prev.map((c) =>
          c.id === conversationId
            ? { ...c, messages: [...c.messages, botMsg] }
            : c
        )
      );
    }, 500);
  };

  const getStats = () => {
    let totalAnswered = 0;
    let totalCorrect = 0;
    const topicErrors: Record<string, number> = {};
    for (const a of attempts) {
      totalAnswered += a.total;
      totalCorrect += a.score;
    }
    for (const f of flashcards) {
      totalAnswered += f.timesReviewed;
      totalCorrect += f.timesCorrect;
      if (f.timesIncorrect > f.timesCorrect) {
        const topic = f.question.slice(0, 40);
        topicErrors[topic] = (topicErrors[topic] || 0) + f.timesIncorrect;
      }
    }
    const weakTopics = Object.entries(topicErrors)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([t]) => t);
    return {
      totalMaterials: materials.length,
      totalQuestionsAnswered: totalAnswered,
      totalCorrect,
      accuracy:
        totalAnswered > 0
          ? Math.round((totalCorrect / totalAnswered) * 100)
          : 0,
      weakTopics,
      studyStreak: 0,
    };
  };

  const clearAllData = () => {
    setMaterials([]);
    setSummaries([]);
    setFlashcards([]);
    setQuestions([]);
    setAttempts([]);
    setPlans([]);
    setConversations([]);
    setActiveConversationId(null);
  };

  const value: AppContextValue = {
    user,
    isOnboarded,
    materials,
    summaries,
    flashcards,
    questions,
    attempts,
    plans,
    conversations,
    activeConversationId,
    completeOnboarding,
    updateUser,
    addMaterial,
    updateMaterial,
    deleteMaterial,
    processMaterial,
    prepareStudyPackage,
    updateFlashcard,
    addAttempt,
    addPlan,
    updatePlan,
    createConversation,
    sendChatMessage,
    setActiveConversation: setActiveConversationId,
    getStats,
    clearAllData,
    ready,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppStore() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppStore must be used within AppProvider");
  return ctx;
}
