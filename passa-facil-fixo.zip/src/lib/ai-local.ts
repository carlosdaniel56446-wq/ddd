import type {
  MaterialAnalysis,
  Summary,
  Flashcard,
  Question,
  Difficulty,
} from "@/types";
import { generateId } from "./utils";

/** Simple keyword-based subject detection for Brazilian education context */
const SUBJECT_KEYWORDS: Record<string, string[]> = {
  Matemática: [
    "equação", "função", "derivada", "integral", "álgebra", "geometria",
    "trigonometria", "probabilidade", "estatística", "matriz", "vetor",
    "logaritmo", "polinômio", "raiz", "fração", "porcentagem", "sistema linear",
  ],
  Português: [
    "gramática", "sintaxe", "morfologia", "concordância", "regência",
    "figura de linguagem", "texto", "interpretação", "redação", "literatura",
    "poesia", "narrativa", "verbo", "substantivo", "adjetivo", "crase",
  ],
  História: [
    "século", "império", "república", "revolução", "guerra", "colonização",
    "independência", "ditadura", "democracia", "feudalismo", "iluminismo",
    "idade média", "brasil colônia", "era vargas", "cold war", "guerra fria",
  ],
  Geografia: [
    "clima", "relevo", "hidrografia", "população", "urbanização", "globalização",
    "cartografia", "bioma", "amazônia", "cerrado", "região", "país", "continente",
    "economia", "indústria", "agricultura", "migração",
  ],
  Física: [
    "força", "energia", "velocidade", "aceleração", "newton", "óptica",
    "eletricidade", "magnetismo", "onda", "termologia", "cinemática",
    "dinâmica", "trabalho", "potência", "calor", "temperatura", "campo",
  ],
  Química: [
    "átomo", "molécula", "reação", "ácido", "base", "sal", "oxidação",
    "redução", "tabela periódica", "ligação", "composto", "elemento",
    "estequiometria", "solução", "ph", "orgânica", "inorgânica",
  ],
  Biologia: [
    "célula", "dna", "gene", "evolução", "ecologia", "fotossíntese",
    "sistema", "órgão", "tecido", "reprodução", "genética", "biodiversidade",
    "reino", "espécie", "metabolismo", "enzima", "vírus", "bactéria",
  ],
  Filosofia: [
    "ética", "moral", "existência", "conhecimento", "razão", "platão",
    "aristóteles", "kant", "nietzsche", "existência", "metafísica", "lógica",
  ],
  Sociologia: [
    "sociedade", "classe", "cultura", "poder", "estado", "instituição",
    "durkheim", "weber", "marx", "socialização", "desigualdade",
  ],
  Inglês: [
    "verb", "tense", "grammar", "vocabulary", "reading", "listening",
    "present", "past", "future", "conditional", "phrasal",
  ],
};

function detectSubject(text: string): string {
  const lower = text.toLowerCase();
  let best = "Geral";
  let maxScore = 0;
  for (const [subject, keywords] of Object.entries(SUBJECT_KEYWORDS)) {
    const score = keywords.filter((k) => lower.includes(k.toLowerCase())).length;
    if (score > maxScore) {
      maxScore = score;
      best = subject;
    }
  }
  return best;
}

function extractSentences(text: string): string[] {
  return text
    .replace(/\n+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 20 && s.length < 400);
}

function extractKeyPhrases(text: string, max = 12): string[] {
  const words = text
    .toLowerCase()
    .replace(/[^\wÀ-ÿ\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 4);
  const freq: Record<string, number> = {};
  for (const w of words) {
    freq[w] = (freq[w] || 0) + 1;
  }
  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, max)
    .map(([w]) => w.charAt(0).toUpperCase() + w.slice(1));
}

function extractDefinitions(text: string): { term: string; definition: string }[] {
  const defs: { term: string; definition: string }[] = [];
  // Pattern: "X é ..." or "X: ..."
  const patterns = [
    /([A-ZÀ-Ÿ][a-zà-ÿA-ZÀ-Ÿ\s]{2,40})\s+(?:é|são|significa|consiste em|define-se como)\s+([^.!?]{15,180})/gi,
    /([A-ZÀ-Ÿ][a-zà-ÿA-ZÀ-Ÿ\s]{2,40})\s*:\s*([^.!?]{15,180})/g,
  ];
  for (const re of patterns) {
    let m;
    while ((m = re.exec(text)) !== null && defs.length < 10) {
      const term = m[1].trim();
      const definition = m[2].trim();
      if (term.length > 2 && !defs.some((d) => d.term === term)) {
        defs.push({ term, definition });
      }
    }
  }
  return defs;
}

function extractFormulas(text: string): string[] {
  const formulas: string[] = [];
  // Simple math-like patterns
  const re = /([A-Za-z0-9²³√∫∑πΔθλμ]\s*[=+\-*/^(){}[\]]+\s*[A-Za-z0-9²³√∫∑πΔθλμ\s+\-*/^(){}[\]]{3,60})/g;
  let m;
  while ((m = re.exec(text)) !== null && formulas.length < 8) {
    const f = m[1].trim();
    if (f.includes("=") && !formulas.includes(f)) formulas.push(f);
  }
  return formulas;
}

function scoreSentence(s: string, keywords: string[]): number {
  const lower = s.toLowerCase();
  let score = 0;
  for (const k of keywords) {
    if (lower.includes(k.toLowerCase())) score += 2;
  }
  if (s.length > 40 && s.length < 200) score += 1;
  if (/^(é|são|define|consiste|importante|principal|conceito)/i.test(s)) score += 2;
  return score;
}

export function analyzeMaterial(text: string, title?: string): MaterialAnalysis {
  const subject = detectSubject(text);
  const keywords = extractKeyPhrases(text, 15);
  const sentences = extractSentences(text);
  const scored = sentences
    .map((s) => ({ s, score: scoreSentence(s, keywords) }))
    .sort((a, b) => b.score - a.score);
  const topSentences = scored.slice(0, 8).map((x) => x.s);

  const definitions = extractDefinitions(text);
  const formulas = extractFormulas(text);

  const topics = keywords.slice(0, 8);
  const keyConcepts = [
    ...definitions.map((d) => d.term),
    ...keywords.slice(0, 6),
  ].filter((v, i, a) => a.indexOf(v) === i).slice(0, 10);

  const difficulty: Difficulty =
    text.length > 3000 || formulas.length > 3 || definitions.length > 5
      ? "dificil"
      : text.length > 1200
        ? "medio"
        : "facil";

  const summary =
    topSentences.slice(0, 4).join(" ") ||
    "Conteúdo analisado. Revise os tópicos identificados.";

  return {
    mainSubject: subject,
    suggestedSubject: subject,
    topics,
    keyConcepts,
    definitions,
    formulas,
    difficulty,
    summary,
    structure: [
      "Introdução e conceitos básicos",
      ...topics.slice(0, 4).map((t) => `Tópico: ${t}`),
      "Pontos para memorizar",
      "Exercícios e aplicação",
    ],
  };
}

export function generateSummary(
  materialId: string,
  text: string,
  analysis: MaterialAnalysis,
  title: string
): Summary {
  const sentences = extractSentences(text);
  const quick = analysis.summary.slice(0, 280) + (analysis.summary.length > 280 ? "…" : "");
  const full =
    sentences.slice(0, 12).join(" ") ||
    analysis.summary +
      "\n\n" +
      analysis.keyConcepts.map((c) => `• ${c}`).join("\n");

  return {
    id: generateId(),
    materialId,
    title: `Resumo — ${title}`,
    quickSummary: quick,
    fullSummary: full,
    topics: analysis.topics,
    keyConcepts: analysis.keyConcepts,
    definitions: analysis.definitions,
    formulas: analysis.formulas,
    toMemorize: [
      ...analysis.definitions.map((d) => `${d.term}: ${d.definition}`),
      ...analysis.formulas,
      ...analysis.keyConcepts.slice(0, 5),
    ].slice(0, 12),
    glossary: analysis.definitions,
    createdAt: new Date().toISOString(),
  };
}

export function generateFlashcards(
  materialId: string,
  analysis: MaterialAnalysis,
  text: string
): Flashcard[] {
  const cards: Flashcard[] = [];
  const now = new Date().toISOString();

  for (const def of analysis.definitions.slice(0, 8)) {
    cards.push({
      id: generateId(),
      materialId,
      question: `O que é ${def.term}?`,
      answer: def.definition,
      difficulty: "medio",
      needsReview: false,
      timesReviewed: 0,
      timesCorrect: 0,
      timesIncorrect: 0,
      createdAt: now,
    });
  }

  for (const concept of analysis.keyConcepts.slice(0, 6)) {
    if (cards.some((c) => c.question.includes(concept))) continue;
    cards.push({
      id: generateId(),
      materialId,
      question: `Explique o conceito de ${concept}.`,
      answer: `Conceito importante relacionado a ${analysis.mainSubject}. Revise o material original para a definição completa.`,
      difficulty: "medio",
      needsReview: false,
      timesReviewed: 0,
      timesCorrect: 0,
      timesIncorrect: 0,
      createdAt: now,
    });
  }

  for (const formula of analysis.formulas.slice(0, 4)) {
    cards.push({
      id: generateId(),
      materialId,
      question: `Qual a fórmula / expressão: ${formula.split("=")[0]?.trim() || formula}?`,
      answer: formula,
      difficulty: "dificil",
      needsReview: false,
      timesReviewed: 0,
      timesCorrect: 0,
      timesIncorrect: 0,
      createdAt: now,
    });
  }

  // From sentences
  const sentences = extractSentences(text).slice(0, 5);
  for (const s of sentences) {
    if (cards.length >= 15) break;
    const words = s.split(" ");
    if (words.length < 8) continue;
    const blankIdx = Math.floor(words.length / 2);
    const answer = words[blankIdx];
    const question = words.map((w, i) => (i === blankIdx ? "______" : w)).join(" ");
    cards.push({
      id: generateId(),
      materialId,
      question: `Complete: ${question}`,
      answer,
      difficulty: "facil",
      needsReview: false,
      timesReviewed: 0,
      timesCorrect: 0,
      timesIncorrect: 0,
      createdAt: now,
    });
  }

  return cards.slice(0, 15);
}

export function generateQuestions(
  materialId: string,
  analysis: MaterialAnalysis,
  text: string,
  count = 8
): Question[] {
  const questions: Question[] = [];
  const now = Date.now();

  // True/False from key concepts
  for (const concept of analysis.keyConcepts.slice(0, 4)) {
    if (questions.length >= count) break;
    questions.push({
      id: generateId(),
      materialId,
      type: "truefalse",
      question: `${concept} é um conceito central de ${analysis.mainSubject}.`,
      correctAnswer: true,
      explanation: `Sim, ${concept} foi identificado como um dos conceitos principais no material.`,
      difficulty: "facil",
      topic: concept,
    });
  }

  // Multiple choice from definitions
  for (const def of analysis.definitions.slice(0, 4)) {
    if (questions.length >= count) break;
    const wrong = analysis.definitions
      .filter((d) => d.term !== def.term)
      .slice(0, 3)
      .map((d) => d.definition);
    while (wrong.length < 3) {
      wrong.push("Nenhuma das alternativas anteriores.");
    }
    const options = [def.definition, ...wrong].sort(() => Math.random() - 0.5);
    questions.push({
      id: generateId(),
      materialId,
      type: "multiple",
      question: `O que significa / define "${def.term}"?`,
      options,
      correctAnswer: def.definition,
      explanation: `A definição correta de ${def.term} é: ${def.definition}`,
      commonMistakes: "Confundir com conceitos próximos do mesmo assunto.",
      difficulty: "medio",
      topic: def.term,
    });
  }

  // Open questions
  for (const topic of analysis.topics.slice(0, 3)) {
    if (questions.length >= count) break;
    questions.push({
      id: generateId(),
      materialId,
      type: "open",
      question: `Explique com suas palavras o que você entendeu sobre "${topic}".`,
      correctAnswer: `Resposta esperada deve abordar os pontos principais de ${topic} conforme o material.`,
      explanation: `Verifique se você mencionou os conceitos-chave relacionados a ${topic}.`,
      difficulty: "medio",
      topic,
    });
  }

  return questions.slice(0, count);
}

export function generateExplanation(
  concept: string,
  level: "simples" | "avancado" | "zero" = "simples"
): string {
  if (level === "zero") {
    return `Vamos começar do zero sobre "${concept}". Imagine que você nunca ouviu falar disso. Em termos bem simples: é um conceito importante nos estudos. Para entender melhor, leia o trecho do seu material e tente explicar com suas próprias palavras. Se ficar com dúvida, peça outro exemplo!`;
  }
  if (level === "avancado") {
    return `Sobre "${concept}" em nível mais aprofundado: esse conceito se relaciona com outros tópicos do material. Analise as relações de causa e efeito, as definições precisas e as aplicações práticas. Compare com o que você já sabe e tente formular uma definição própria.`;
  }
  return `Explicação simples de "${concept}": é um dos pontos principais identificados no seu material. Foque em entender a ideia central e depois os detalhes. Use exemplos do cotidiano quando possível e revise o resumo gerado.`;
}

export function chatResponse(
  userMessage: string,
  materialText?: string,
  analysis?: MaterialAnalysis
): string {
  const lower = userMessage.toLowerCase();

  if (lower.includes("resumo") || lower.includes("resuma")) {
    return analysis
      ? `Aqui está um resumo baseado no seu material:\n\n${analysis.summary}\n\nTópicos principais: ${analysis.topics.join(", ")}.`
      : "Envie um material primeiro para eu poder resumir o conteúdo.";
  }

  if (lower.includes("explique") || lower.includes("o que é") || lower.includes("como funciona")) {
    const concept =
      analysis?.keyConcepts.find((c) => lower.includes(c.toLowerCase())) ||
      analysis?.topics[0] ||
      "o assunto";
    return generateExplanation(concept, "simples") +
      (materialText
        ? `\n\nBaseado no seu material: "${materialText.slice(0, 200)}…"`
        : "");
  }

  if (lower.includes("exemplo") || lower.includes("dê mais")) {
    return "Aqui vai um exemplo prático: imagine uma situação do dia a dia relacionada ao conceito. Tente aplicar a definição que está no material. Se quiser, peça um exemplo mais específico citando o tópico.";
  }

  if (lower.includes("exercício") || lower.includes("questão") || lower.includes("prática")) {
    return "Posso gerar questões de prática! Vá na seção Exercícios ou Flashcards, ou me diga o tópico que deseja treinar.";
  }

  if (lower.includes("dica") || lower.includes("como estudar")) {
    return "Dica de estudo: 1) Leia o resumo rápido. 2) Faça os flashcards marcando o que é difícil. 3) Resolva questões e revise os erros. 4) Use a revisão espaçada. Foque nos assuntos com mais erros primeiro!";
  }

  // Default
  if (analysis) {
    return `Entendi sua pergunta sobre o material de ${analysis.mainSubject}. Os tópicos principais são: ${analysis.topics.slice(0, 5).join(", ")}. \n\nPosso explicar algum conceito específico, gerar exemplos, criar questões ou resumir uma parte. O que você prefere?`;
  }

  return "Olá! Sou o Professor IA do Passa Fácil. Envie um material de estudo e eu ajudo a explicar, criar resumos, flashcards e questões. Como posso te ajudar agora?";
}
