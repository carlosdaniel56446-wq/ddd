import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import "./globals.css";
import { AppShell } from "@/components/AppShell";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
});

export const metadata: Metadata = {
  title: "Passa Fácil — Plataforma Inteligente de Estudos",
  description:
    "Envie seu material. A IA organiza seus estudos e prepara o que você precisa para aprender.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className={`${inter.variable} min-h-screen antialiased font-sans`}>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
