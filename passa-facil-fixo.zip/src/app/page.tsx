"use client";

import type { ElementType } from "react";

import Link from "next/link";
import {
  IconUpload, IconBook, IconLayers, IconHelp, IconBot,
  IconSparkles, IconChart, IconChevron,
} from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { formatRelative, truncate } from "@/lib/utils";

export default function HomePage() {
  const { user, materials, summaries, flashcards, attempts, getStats } =
    useAppStore();
  const stats = getStats();
  const recentMaterials = materials.slice(0, 4);
  const hasData = materials.length > 0;

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
          Olá, {user?.name?.split(" ")[0] || "Estudante"}! 👋
        </h1>
        <p className="text-muted-foreground mt-1">
          {hasData
            ? "Continue de onde parou ou envie um novo material."
            : "Bem-vindo ao Passa Fácil. Envie seu primeiro material para começar."}
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Link
          href="/upload"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground shadow-sm hover:opacity-90 transition"
        >
          <IconUpload className="h-5 w-5" />
          Enviar material
        </Link>
        {hasData && (
          <Link
            href="/flashcards"
            className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card px-6 py-3.5 font-semibold hover:bg-muted transition"
          >
            <IconSparkles className="h-5 w-5 text-primary" />
            Começar a estudar
          </Link>
        )}
      </div>

      {!hasData && (
        <div className="rounded-2xl border border-dashed border-border bg-card/50 p-8 sm:p-12 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
            <IconBook className="h-8 w-8 text-primary" />
          </div>
          <h2 className="text-lg font-semibold mb-2">Comece em 3 passos</h2>
          <ol className="text-sm text-muted-foreground space-y-2 max-w-md mx-auto text-left list-decimal list-inside">
            <li>Envie um PDF, imagem ou cole um texto de estudo</li>
            <li>A IA analisa e sugere matéria e tópicos</li>
            <li>Gere resumo, flashcards e questões automaticamente</li>
          </ol>
          <Link
            href="/upload"
            className="inline-flex mt-6 items-center gap-2 text-primary font-medium hover:underline"
          >
            Enviar meu primeiro material →
          </Link>
        </div>
      )}

      {hasData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard label="Materiais" value={stats.totalMaterials} icon={IconBook} />
          <StatCard label="Questões" value={stats.totalQuestionsAnswered} icon={IconHelp} />
          <StatCard label="Acertos" value={`${stats.accuracy}%`} icon={IconChart} />
          <StatCard label="Flashcards" value={flashcards.length} icon={IconLayers} />
        </div>
      )}

      {recentMaterials.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-lg">Materiais recentes</h2>
            <Link href="/materiais" className="text-sm text-primary hover:underline">
              Ver todos
            </Link>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {recentMaterials.map((m) => (
              <Link
                key={m.id}
                href="/materiais"
                className="rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-medium text-sm line-clamp-1">{m.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {m.subject || "Sem matéria"} · {formatRelative(m.createdAt)}
                    </p>
                  </div>
                  <StatusBadge status={m.status} />
                </div>
                {m.topics.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {m.topics.slice(0, 3).map((t) => (
                      <span key={t} className="rounded-full bg-muted px-2 py-0.5 text-[10px] text-muted-foreground">
                        {truncate(t, 18)}
                      </span>
                    ))}
                  </div>
                )}
              </Link>
            ))}
          </div>
        </section>
      )}

      {hasData && (
        <section>
          <h2 className="font-semibold text-lg mb-3">Atalhos</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <QuickLink href="/resumos" icon={IconBook} label="Resumos" count={summaries.length} />
            <QuickLink href="/flashcards" icon={IconLayers} label="Flashcards" count={flashcards.length} />
            <QuickLink href="/exercicios" icon={IconHelp} label="Exercícios" count={attempts.length} />
            <QuickLink href="/professor" icon={IconBot} label="Professor IA" />
          </div>
        </section>
      )}

      {stats.weakTopics.length > 0 && (
        <section className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
          <h2 className="font-semibold text-sm mb-2">Assuntos que precisam de reforço</h2>
          <ul className="text-sm text-muted-foreground space-y-1">
            {stats.weakTopics.map((t, i) => (
              <li key={i}>• {t}</li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function StatCard({ label, value, icon: Icon }: { label: string; value: string | number; icon: ElementType }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-muted-foreground mb-1">
        <Icon className="h-4 w-4" />
        <span className="text-xs">{label}</span>
      </div>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

function QuickLink({ href, icon: Icon, label, count }: { href: string; icon: ElementType; label: string; count?: number }) {
  return (
    <Link href={href} className="flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 hover:border-primary/40 transition text-center">
      <Icon className="h-6 w-6 text-primary" />
      <span className="text-sm font-medium">{label}</span>
      {typeof count === "number" && (
        <span className="text-xs text-muted-foreground">{count} itens</span>
      )}
    </Link>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    processing: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
    analyzed: "bg-blue-500/15 text-blue-700 dark:text-blue-400",
    ready: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
    error: "bg-red-500/15 text-red-700 dark:text-red-400",
  };
  const labels: Record<string, string> = {
    processing: "Processando",
    analyzed: "Analisado",
    ready: "Pronto",
    error: "Erro",
  };
  return (
    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-medium ${map[status] || "bg-muted text-muted-foreground"}`}>
      {labels[status] || status}
    </span>
  );
}
