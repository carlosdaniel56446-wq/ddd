"use client";

import { useState } from "react";
import { IconFile } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { formatRelative } from "@/lib/utils";

export default function ResumosPage() {
  const { summaries, materials } = useAppStore();
  const [openId, setOpenId] = useState<string | null>(summaries[0]?.id || null);

  if (summaries.length === 0) {
    return (
      <div className="text-center py-16">
        <IconFile className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h1 className="text-xl font-semibold mb-2">Nenhum resumo</h1>
        <p className="text-muted-foreground">Prepare um pacote de estudos a partir de um material analisado.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">Resumos</h1>
      <div className="space-y-4">
        {summaries.map((s) => {
          const mat = materials.find((m) => m.id === s.materialId);
          const open = openId === s.id;
          return (
            <div key={s.id} className="rounded-xl border border-border bg-card overflow-hidden">
              <button onClick={() => setOpenId(open ? null : s.id)} className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/50">
                <div>
                  <p className="font-semibold">{s.title}</p>
                  <p className="text-xs text-muted-foreground">{mat?.subject} · {formatRelative(s.createdAt)}</p>
                </div>
                <span className="text-muted-foreground text-sm">{open ? "−" : "+"}</span>
              </button>
              {open && (
                <div className="border-t border-border p-4 space-y-4 text-sm">
                  <div>
                    <h3 className="font-medium mb-1">Resumo rápido</h3>
                    <p className="text-muted-foreground leading-relaxed">{s.quickSummary}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Resumo completo</h3>
                    <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{s.fullSummary}</p>
                  </div>
                  {s.keyConcepts.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-1">Conceitos essenciais</h3>
                      <ul className="list-disc list-inside text-muted-foreground">
                        {s.keyConcepts.map((c) => <li key={c}>{c}</li>)}
                      </ul>
                    </div>
                  )}
                  {s.definitions.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-1">Definições</h3>
                      <dl className="space-y-2">
                        {s.definitions.map((d) => (
                          <div key={d.term}>
                            <dt className="font-medium">{d.term}</dt>
                            <dd className="text-muted-foreground pl-2">{d.definition}</dd>
                          </div>
                        ))}
                      </dl>
                    </div>
                  )}
                  {s.toMemorize.length > 0 && (
                    <div>
                      <h3 className="font-medium mb-1">Para memorizar</h3>
                      <ul className="list-disc list-inside text-muted-foreground">
                        {s.toMemorize.map((t, i) => <li key={i}>{t}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
