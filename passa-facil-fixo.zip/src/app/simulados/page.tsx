"use client";

import { useState } from "react";
import { IconClipboard } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { generateId } from "@/lib/utils";
import type { Question } from "@/types";

export default function SimuladosPage() {
  const { questions, addAttempt } = useAppStore();
  const [started, setStarted] = useState(false);
  const [selected, setSelected] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, string | boolean>>({});
  const [finished, setFinished] = useState(false);
  const [score, setScore] = useState(0);
  const [qty, setQty] = useState(5);

  const start = () => {
    const pool = [...questions].sort(() => Math.random() - 0.5).slice(0, qty);
    setSelected(pool);
    setAnswers({});
    setFinished(false);
    setStarted(true);
  };

  const finish = () => {
    let s = 0;
    for (const q of selected) {
      if (answers[q.id] === q.correctAnswer) s++;
    }
    setScore(s);
    setFinished(true);
    addAttempt({
      id: generateId(),
      materialId: selected[0]?.materialId || "",
      questions: selected,
      answers,
      score: s,
      total: selected.length,
      completedAt: new Date().toISOString(),
    });
  };

  if (questions.length === 0) {
    return (
      <div className="text-center py-16">
        <IconClipboard className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h1 className="text-xl font-semibold">Nenhuma questão para simulado</h1>
        <p className="text-muted-foreground mt-2">Gere questões a partir dos materiais primeiro.</p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">Simulados</h1>
      <p className="text-sm text-muted-foreground">Questões elaboradas para prática (não são oficiais).</p>
      {!started ? (
        <div className="rounded-xl border border-border bg-card p-6 space-y-4">
          <div>
            <label className="text-sm font-medium">Quantidade de questões</label>
            <input type="number" min={3} max={Math.min(20, questions.length)} value={qty} onChange={(e) => setQty(Number(e.target.value) || 5)} className="mt-1 w-full rounded-lg border border-border px-3 py-2" />
          </div>
          <button onClick={start} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground">Iniciar simulado</button>
        </div>
      ) : (
        <div className="space-y-4">
          {selected.map((q, i) => (
            <div key={q.id} className="rounded-xl border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground mb-1">Q{i + 1}</p>
              <p className="font-medium mb-3">{q.question}</p>
              {q.type === "multiple" && q.options?.map((opt) => (
                <label key={opt} className="flex items-center gap-2 mb-2 text-sm cursor-pointer">
                  <input type="radio" name={q.id} disabled={finished} checked={answers[q.id] === opt} onChange={() => setAnswers((a) => ({ ...a, [q.id]: opt }))} />
                  {opt}
                </label>
              ))}
              {q.type === "truefalse" && (
                <div className="flex gap-2">
                  {[true, false].map((v) => (
                    <button key={String(v)} disabled={finished} onClick={() => setAnswers((a) => ({ ...a, [q.id]: v }))} className={`flex-1 rounded-lg border py-2 text-sm ${answers[q.id] === v ? "border-primary bg-primary/10" : ""}`}>
                      {v ? "V" : "F"}
                    </button>
                  ))}
                </div>
              )}
              {finished && (
                <p className={`mt-2 text-sm ${answers[q.id] === q.correctAnswer ? "text-emerald-600" : "text-destructive"}`}>
                  {answers[q.id] === q.correctAnswer ? "✓ Correto" : `✗ ${q.explanation}`}
                </p>
              )}
            </div>
          ))}
          {!finished ? (
            <button onClick={finish} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground">Finalizar</button>
          ) : (
            <div className="text-center rounded-xl border bg-card p-6">
              <p className="text-3xl font-bold">{score}/{selected.length}</p>
              <button onClick={() => setStarted(false)} className="mt-4 text-sm text-primary">Novo simulado</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
