"use client";

import { useState } from "react";
import { useAppStore } from "@/store/AppContext";
import type { StudyProfile } from "@/types";

const PROFILES: { id: StudyProfile; label: string }[] = [
  { id: "fundamental", label: "Ensino Fundamental" },
  { id: "medio", label: "Ensino Médio" },
  { id: "enem", label: "ENEM e Vestibulares" },
  { id: "superior", label: "Ensino Superior" },
  { id: "tecnico", label: "Curso Técnico" },
  { id: "concurso", label: "Concursos" },
  { id: "outro", label: "Outro" },
];

export default function ConfigPage() {
  const { user, updateUser, clearAllData } = useAppStore();
  const [name, setName] = useState(user?.name || "");
  const [confirmClear, setConfirmClear] = useState(false);

  return (
    <div className="max-w-lg space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Configurações</h1>
        <p className="text-sm text-muted-foreground">
          Personalize sua experiência
        </p>
      </div>

      <section className="space-y-3">
        <h2 className="font-semibold">Perfil</h2>
        <div>
          <label className="text-sm text-muted-foreground">Nome</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => name.trim() && updateUser({ name: name.trim() })}
            className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2"
          />
        </div>
        <div>
          <label className="text-sm text-muted-foreground">Perfil de estudo</label>
          <select
            value={user?.profile || "medio"}
            onChange={(e) =>
              updateUser({ profile: e.target.value as StudyProfile })
            }
            className="mt-1 w-full rounded-lg border border-border bg-card px-3 py-2"
          >
            {PROFILES.map((p) => (
              <option key={p.id} value={p.id}>
                {p.label}
              </option>
            ))}
          </select>
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-semibold">Dados</h2>
        <p className="text-sm text-muted-foreground">
          Os dados ficam salvos neste navegador (localStorage). Não há conta na
          nuvem nesta versão.
        </p>
        {!confirmClear ? (
          <button
            onClick={() => setConfirmClear(true)}
            className="rounded-lg border border-destructive/40 px-4 py-2 text-sm text-destructive hover:bg-destructive/10"
          >
            Apagar todos os dados
          </button>
        ) : (
          <div className="flex gap-2 items-center">
            <span className="text-sm text-destructive">Tem certeza?</span>
            <button
              onClick={() => {
                clearAllData();
                setConfirmClear(false);
              }}
              className="rounded-lg bg-destructive px-3 py-1.5 text-sm text-white"
            >
              Sim, apagar
            </button>
            <button
              onClick={() => setConfirmClear(false)}
              className="text-sm text-muted-foreground"
            >
              Cancelar
            </button>
          </div>
        )}
      </section>

      <section className="rounded-xl border border-border bg-muted/30 p-4 text-sm text-muted-foreground">
        <p className="font-medium text-foreground mb-1">Sobre o Passa Fácil</p>
        <p>
          Versão MVP. Análise e geração de conteúdo usam processamento local
          inteligente. Para IA generativa completa (modelos grandes), configure
          uma chave de API nas próximas versões.
        </p>
        <p className="mt-2">
          Pronto para deploy na Vercel com Next.js.
        </p>
      </section>
    </div>
  );
}
