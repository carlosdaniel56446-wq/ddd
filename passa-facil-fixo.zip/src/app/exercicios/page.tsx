"use client";

import { useState, useMemo } from "react";
import { IconHelp, IconCheck, IconX } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { generateId } from "@/lib/utils";
import type { Question } from "@/types";

export default function ExerciciosPage() {
  const { questions, materials, addAttempt } = useAppStore();
  const [filterMaterial, setFilterMaterial] = useState("all");
  const [started, setStarted] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string | boolean>>({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState<{ score: number; total: number } | null>(null);

  const filtered = useMemo(() => {
    let qs = questions;
    if (filterMaterial !== "all") qs = qs.filter((q) => q.materialId === filterMaterial);
    return qs.slice(0, 10);
  }, [questions, filterMaterial]);

  const handleSubmit = () => {
    let score = 0;
    for (const q of filtered) {
      const ans = answers[q.id];
      if (q.type === "truefalse" || q.type === "multiple") {
        if (ans === q.correctAnswer) score++;
      } else if (typeof ans === "string" && ans.trim().length > 10) {
        score += 0.5;
      }
    }
    const total = filtered.length;
    const finalScore = Math.round(score);
    setResult({ score: finalScore, total });
    setSubmitted(true);
    addAttempt({
      id: generateId(),
      materialId: filterMaterial === "all" ? filtered[0]?.materialId || "" : filterMaterial,
      questions: filtered,
      answers,
      score: finalScore,
      total,
      completedAt: new Date().toISOString(),
    });
  };

  if (questions.length === 0) {
    return (
      <div className="text-center py-16">
        <IconHelp className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h1 className="text-xl font-semibold mb-2">Nenhum exercício</h1>
        <p className="text-muted-foreground">Prepare um pacote de estudos a partir de um material.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold">Exercícios</h1>
        <p className="text-sm text-muted-foreground">Questões geradas a partir dos seus materiais</p>
      </div>

      {!started ? (
        <div className="rounded-xl border border-border bg-card p-6 space-y-4">
          <label className="text-sm font-medium block">Material</label>
          <select value={filterMaterial} onChange={(e) => setFilterMaterial(e.target.value)} className="w-full rounded-lg border border-border bg-background px-3 py-2">
            <option value="all">Todos</option>
            {materials.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}
          </select>
          <p className="text-sm text-muted-foreground">{filtered.length} questões disponíveis</p>
          <button onClick={() => { setStarted(true); setAnswers({}); setSubmitted(false); setResult(null); }} disabled={filtered.length === 0} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground disabled:opacity-50">
            Começar
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          {filtered.map((q, idx) => (
            <QuestionCard key={q.id} q={q} idx={idx} answer={answers[q.id]} onAnswer={(v) => setAnswers((a) => ({ ...a, [q.id]: v }))} showResult={submitted} />
          ))}
          {!submitted ? (
            <button onClick={handleSubmit} className="w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground">Finalizar e corrigir</button>
          ) : (
            <div className="rounded-xl border border-border bg-card p-6 text-center">
              <p className="text-3xl font-bold">{result?.score}/{result?.total}</p>
              <p className="text-muted-foreground mt-1">
                {result && result.total > 0 ? Math.round((result.score / result.total) * 100) : 0}% de acertos
              </p>
              <button onClick={() => { setStarted(false); setSubmitted(false); }} className="mt-4 rounded-lg border border-border px-4 py-2 text-sm">Voltar</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function QuestionCard({ q, idx, answer, onAnswer, showResult }: { q: Question; idx: number; answer: string | boolean | undefined; onAnswer: (v: string | boolean) => void; showResult: boolean }) {
  const isCorrect = q.type === "open" ? typeof answer === "string" && answer.trim().length > 10 : answer === q.correctAnswer;
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-xs text-muted-foreground mb-1">Questão {idx + 1} · {q.type === "multiple" ? "Múltipla escolha" : q.type === "truefalse" ? "V ou F" : "Aberta"}</p>
      <p className="font-medium mb-3">{q.question}</p>
      {q.type === "multiple" && q.options && (
        <div className="space-y-2">
          {q.options.map((opt) => (
            <label key={opt} className={`flex items-center gap-2 rounded-lg border p-3 cursor-pointer text-sm ${answer === opt ? "border-primary bg-primary/5" : "border-border"}`}>
              <input type="radio" name={q.id} checked={answer === opt} onChange={() => onAnswer(opt)} disabled={showResult} className="accent-primary" />
              {opt}
            </label>
          ))}
        </div>
      )}
      {q.type === "truefalse" && (
        <div className="flex gap-3">
          {[true, false].map((v) => (
            <button key={String(v)} onClick={() => onAnswer(v)} disabled={showResult} className={`flex-1 rounded-lg border py-2.5 text-sm font-medium ${answer === v ? "border-primary bg-primary/10" : "border-border"}`}>
              {v ? "Verdadeiro" : "Falso"}
            </button>
          ))}
        </div>
      )}
      {q.type === "open" && (
        <textarea value={(answer as string) || ""} onChange={(e) => onAnswer(e.target.value)} disabled={showResult} rows={3} placeholder="Escreva sua resposta..." className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm" />
      )}
      {showResult && (
        <div className={`mt-3 rounded-lg px-3 py-2 text-sm flex items-start gap-2 ${isCorrect ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400" : "bg-destructive/10 text-destructive"}`}>
          {isCorrect ? <IconCheck className="h-4 w-4 shrink-0 mt-0.5" /> : <IconX className="h-4 w-4 shrink-0 mt-0.5" />}
          <div>
            <p className="font-medium">{isCorrect ? "Correto" : "Incorreto"}</p>
            <p className="mt-0.5 opacity-90">{q.explanation}</p>
            {q.type !== "open" && !isCorrect && <p className="mt-1 text-xs">Resposta correta: {String(q.correctAnswer)}</p>}
          </div>
        </div>
      )}
    </div>
  );
}
