"use client";

import Link from "next/link";
import { IconLibrary, IconBook, IconFile, IconLayers, IconHelp } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { formatRelative } from "@/lib/utils";

export default function BibliotecaPage() {
  const { materials, summaries, flashcards, questions, conversations } = useAppStore();

  const items = [
    { type: "Materiais", icon: IconBook, count: materials.length, href: "/materiais", list: materials.slice(0, 5).map((m) => ({ id: m.id, title: m.title, meta: m.subject || formatRelative(m.createdAt) })) },
    { type: "Resumos", icon: IconFile, count: summaries.length, href: "/resumos", list: summaries.slice(0, 5).map((s) => ({ id: s.id, title: s.title, meta: formatRelative(s.createdAt) })) },
    { type: "Flashcards", icon: IconLayers, count: flashcards.length, href: "/flashcards", list: [] as { id: string; title: string; meta: string }[] },
    { type: "Questões", icon: IconHelp, count: questions.length, href: "/exercicios", list: [] as { id: string; title: string; meta: string }[] },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <IconLibrary className="h-6 w-6" /> Biblioteca de estudos
        </h1>
        <p className="text-sm text-muted-foreground">Tudo organizado em um só lugar</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {items.map((item) => (
          <div key={item.type} className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <item.icon className="h-5 w-5 text-primary" />
                <h2 className="font-semibold">{item.type}</h2>
              </div>
              <span className="text-sm text-muted-foreground">{item.count}</span>
            </div>
            {item.list.length > 0 ? (
              <ul className="space-y-2 mb-3">
                {item.list.map((l) => (
                  <li key={l.id} className="text-sm">
                    <span className="font-medium">{l.title}</span>
                    <span className="text-muted-foreground text-xs ml-2">{l.meta}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground mb-3">{item.count === 0 ? "Nenhum item" : `${item.count} itens`}</p>
            )}
            <Link href={item.href} className="text-sm text-primary hover:underline">Ver todos →</Link>
          </div>
        ))}
      </div>
      {conversations.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-semibold mb-2">Conversas com Professor IA</h2>
          <ul className="space-y-1 text-sm">
            {conversations.slice(0, 5).map((c) => (
              <li key={c.id}>
                <Link href="/professor" className="hover:text-primary">{c.title} · {c.messages.length} msgs</Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
