"use client";

import { IconChart, IconBook, IconLayers, IconHelp } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";

export default function ProgressoPage() {
  const { getStats, materials, flashcards, attempts } = useAppStore();
  const stats = getStats();

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Meu progresso</h1>
        <p className="text-sm text-muted-foreground">Dados reais com base no seu uso</p>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl border border-border bg-card p-4">
          <IconBook className="h-5 w-5 text-primary mb-2" />
          <p className="text-2xl font-bold">{stats.totalMaterials}</p>
          <p className="text-xs text-muted-foreground">Materiais</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <IconHelp className="h-5 w-5 text-primary mb-2" />
          <p className="text-2xl font-bold">{stats.totalQuestionsAnswered}</p>
          <p className="text-xs text-muted-foreground">Questões respondidas</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <IconChart className="h-5 w-5 text-primary mb-2" />
          <p className="text-2xl font-bold">{stats.accuracy}%</p>
          <p className="text-xs text-muted-foreground">Taxa de acertos</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <IconLayers className="h-5 w-5 text-primary mb-2" />
          <p className="text-2xl font-bold">{flashcards.length}</p>
          <p className="text-xs text-muted-foreground">Flashcards</p>
        </div>
      </div>
      {stats.weakTopics.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-5">
          <h2 className="font-semibold mb-2">Recomendações</h2>
          <ul className="space-y-2 text-sm">
            {stats.weakTopics.map((t, i) => (
              <li key={i} className="text-muted-foreground">• Revise: <span className="text-foreground font-medium">{t}</span></li>
            ))}
          </ul>
        </div>
      )}
      {attempts.length > 0 && (
        <div>
          <h2 className="font-semibold mb-3">Últimas tentativas</h2>
          <div className="space-y-2">
            {attempts.slice(0, 5).map((a) => (
              <div key={a.id} className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3 text-sm">
                <span>{a.score}/{a.total} acertos</span>
                <span className="text-muted-foreground">{new Date(a.completedAt).toLocaleDateString("pt-BR")}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {stats.totalQuestionsAnswered === 0 && materials.length === 0 && (
        <p className="text-center text-muted-foreground py-8 text-sm">
          Ainda não há dados de progresso. Envie materiais e pratique.
        </p>
      )}
    </div>
  );
}
