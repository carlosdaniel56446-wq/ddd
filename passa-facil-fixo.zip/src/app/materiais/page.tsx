"use client";

import { useState } from "react";
import Link from "next/link";
import { IconBook, IconTrash, IconSparkles, IconRefresh, IconChevron, IconAlert } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { formatRelative, truncate } from "@/lib/utils";

export default function MateriaisPage() {
  const { materials, deleteMaterial, processMaterial, prepareStudyPackage } = useAppStore();
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [preparing, setPreparing] = useState<string | null>(null);

  const handlePrepare = (id: string) => {
    setPreparing(id);
    prepareStudyPackage(id);
    setTimeout(() => setPreparing(null), 600);
  };

  if (materials.length === 0) {
    return (
      <div className="text-center py-16 animate-fade-in">
        <IconBook className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h1 className="text-xl font-semibold mb-2">Nenhum material ainda</h1>
        <p className="text-muted-foreground mb-6">Envie seu primeiro material para começar.</p>
        <Link href="/upload" className="inline-flex rounded-xl bg-primary px-6 py-3 font-medium text-primary-foreground">
          Enviar material
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Meus materiais</h1>
          <p className="text-muted-foreground text-sm">
            {materials.length} material{materials.length !== 1 ? "is" : ""}
          </p>
        </div>
        <Link href="/upload" className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
          Novo
        </Link>
      </div>

      <div className="space-y-3">
        {materials.map((m) => (
          <div key={m.id} className="rounded-xl border border-border bg-card p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <h2 className="font-semibold truncate">{m.title}</h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {m.subject || "—"} · {formatRelative(m.createdAt)}
                  {m.fileName && ` · ${m.fileName}`}
                </p>
              </div>
              <StatusBadge status={m.status} />
            </div>

            {m.status === "error" && m.errorMessage && (
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                <IconAlert className="h-4 w-4 shrink-0 mt-0.5" />
                {m.errorMessage}
              </div>
            )}

            {m.analysis && (
              <div className="mt-3 space-y-2">
                <p className="text-sm text-muted-foreground line-clamp-2">{m.analysis.summary}</p>
                <div className="flex flex-wrap gap-1.5">
                  {m.topics.slice(0, 6).map((t) => (
                    <span key={t} className="rounded-full bg-muted px-2.5 py-0.5 text-xs">{truncate(t, 20)}</span>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                  <span>Dificuldade: {m.analysis.difficulty}</span>
                  <span>·</span>
                  <span>{m.analysis.keyConcepts.length} conceitos</span>
                </div>
              </div>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              {m.status === "analyzed" && (
                <button
                  onClick={() => handlePrepare(m.id)}
                  disabled={preparing === m.id}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground disabled:opacity-60"
                >
                  <IconSparkles className="h-3.5 w-3.5" />
                  {preparing === m.id ? "Preparando…" : "Preparar meus estudos"}
                </button>
              )}
              {m.status === "ready" && (
                <>
                  <Link href="/resumos" className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-muted">
                    Ver resumo <IconChevron className="h-3.5 w-3.5" />
                  </Link>
                  <Link href="/flashcards" className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-muted">
                    Flashcards
                  </Link>
                  <Link href="/exercicios" className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-muted">
                    Exercícios
                  </Link>
                </>
              )}
              {(m.status === "error" || m.status === "processing") && (
                <button onClick={() => processMaterial(m.id)} className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-sm hover:bg-muted">
                  <IconRefresh className="h-3.5 w-3.5" /> Reprocessar
                </button>
              )}
              {confirmId === m.id ? (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-destructive">Excluir?</span>
                  <button onClick={() => { deleteMaterial(m.id); setConfirmId(null); }} className="text-xs font-medium text-destructive">Sim</button>
                  <button onClick={() => setConfirmId(null)} className="text-xs text-muted-foreground">Não</button>
                </div>
              ) : (
                <button onClick={() => setConfirmId(m.id)} className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm text-muted-foreground hover:text-destructive">
                  <IconTrash className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    processing: "bg-amber-500/15 text-amber-700 dark:text-amber-400",
    analyzed: "bg-blue-500/15 text-blue-700 dark:text-blue-400",
    ready: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
    error: "bg-red-500/15 text-red-700 dark:text-red-400",
  };
  const labels: Record<string, string> = {
    processing: "Processando", analyzed: "Analisado", ready: "Pronto", error: "Erro",
  };
  return (
    <span className={`shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium ${map[status] || "bg-muted"}`}>
      {labels[status] || status}
    </span>
  );
}
