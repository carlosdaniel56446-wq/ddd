"use client";

import { useState, useMemo } from "react";
import { IconLayers, IconCheck, IconX } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import type { Difficulty } from "@/types";

export default function FlashcardsPage() {
  const { flashcards, materials, updateFlashcard } = useAppStore();
  const [filterMaterial, setFilterMaterial] = useState<string>("all");
  const [currentIdx, setCurrentIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [mode, setMode] = useState<"list" | "study">("list");

  const filtered = useMemo(() => {
    if (filterMaterial === "all") return flashcards;
    return flashcards.filter((f) => f.materialId === filterMaterial);
  }, [flashcards, filterMaterial]);

  const card = filtered[currentIdx];

  const mark = (correct: boolean, difficulty?: Difficulty) => {
    if (!card) return;
    updateFlashcard(card.id, {
      timesReviewed: card.timesReviewed + 1,
      timesCorrect: card.timesCorrect + (correct ? 1 : 0),
      timesIncorrect: card.timesIncorrect + (correct ? 0 : 1),
      needsReview: !correct,
      difficulty: difficulty || card.difficulty,
      lastReviewed: new Date().toISOString(),
    });
    setFlipped(false);
    setCurrentIdx((i) => (i + 1) % Math.max(filtered.length, 1));
  };

  if (flashcards.length === 0) {
    return (
      <div className="text-center py-16">
        <IconLayers className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h1 className="text-xl font-semibold mb-2">Nenhum flashcard</h1>
        <p className="text-muted-foreground">Prepare um pacote de estudos a partir de um material analisado.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Flashcards</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} cartões</p>
        </div>
        <div className="flex gap-2">
          <select
            value={filterMaterial}
            onChange={(e) => { setFilterMaterial(e.target.value); setCurrentIdx(0); setFlipped(false); }}
            className="rounded-lg border border-border bg-card px-3 py-2 text-sm"
          >
            <option value="all">Todos os materiais</option>
            {materials.map((m) => (
              <option key={m.id} value={m.id}>{m.title}</option>
            ))}
          </select>
          <button
            onClick={() => { setMode(mode === "list" ? "study" : "list"); setCurrentIdx(0); setFlipped(false); }}
            className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            {mode === "list" ? "Estudar" : "Lista"}
          </button>
        </div>
      </div>

      {mode === "study" && card && (
        <div className="max-w-lg mx-auto">
          <p className="text-center text-sm text-muted-foreground mb-3">
            {currentIdx + 1} / {filtered.length}
          </p>
          <div className="perspective cursor-pointer" onClick={() => setFlipped(!flipped)}>
            <div className={`card-inner relative h-64 w-full rounded-2xl border border-border bg-card shadow-sm ${flipped ? "flipped" : ""}`}>
              <div className="card-face absolute inset-0 flex flex-col items-center justify-center p-6 rounded-2xl bg-card">
                <p className="text-xs text-muted-foreground mb-2">Pergunta</p>
                <p className="text-center font-medium text-lg">{card.question}</p>
                <p className="text-xs text-muted-foreground mt-4">Toque para revelar</p>
              </div>
              <div className="card-face card-back absolute inset-0 flex flex-col items-center justify-center p-6 rounded-2xl bg-primary/5 border border-primary/20">
                <p className="text-xs text-muted-foreground mb-2">Resposta</p>
                <p className="text-center font-medium text-lg">{card.answer}</p>
              </div>
            </div>
          </div>
          {flipped && (
            <div className="mt-6 flex flex-col gap-3">
              <div className="flex justify-center gap-3">
                <button onClick={() => mark(false)} className="flex items-center gap-2 rounded-xl border border-destructive/40 px-5 py-2.5 text-sm font-medium text-destructive hover:bg-destructive/10">
                  <IconX className="h-4 w-4" /> Errei
                </button>
                <button onClick={() => mark(true)} className="flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-emerald-700">
                  <IconCheck className="h-4 w-4" /> Acertei
                </button>
              </div>
              <div className="flex justify-center gap-2">
                {(["facil", "medio", "dificil"] as Difficulty[]).map((d) => (
                  <button key={d} onClick={() => mark(true, d)} className="rounded-lg border border-border px-3 py-1 text-xs capitalize hover:bg-muted">
                    {d}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {mode === "list" && (
        <div className="grid gap-3 sm:grid-cols-2">
          {filtered.map((f) => (
            <div key={f.id} className="rounded-xl border border-border bg-card p-4">
              <p className="font-medium text-sm mb-1">{f.question}</p>
              <p className="text-xs text-muted-foreground line-clamp-2">{f.answer}</p>
              <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                <span className="capitalize">{f.difficulty}</span>
                {f.needsReview && <span className="text-amber-600">★ Revisar</span>}
                <span>{f.timesCorrect}/{f.timesReviewed || 0} acertos</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
