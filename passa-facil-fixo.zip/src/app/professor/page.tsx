"use client";

import { useState, useRef, useEffect } from "react";
import { IconBot, IconSend, IconPlus } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";

export default function ProfessorPage() {
  const { conversations, activeConversationId, createConversation, sendChatMessage, materials } = useAppStore();
  const [input, setInput] = useState("");
  const [materialId, setMaterialId] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const conv = conversations.find((c) => c.id === activeConversationId) || conversations[0];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conv?.messages.length]);

  const ensureConv = () => {
    if (!activeConversationId) return createConversation("Conversa com Professor IA", materialId || undefined);
    return activeConversationId;
  };

  const handleSend = () => {
    if (!input.trim()) return;
    const id = ensureConv();
    sendChatMessage(id, input.trim(), materialId || undefined);
    setInput("");
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-3xl mx-auto animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <IconBot className="h-6 w-6 text-primary" /> Professor IA
          </h1>
          <p className="text-sm text-muted-foreground">Tire dúvidas sobre seus materiais</p>
        </div>
        <button onClick={() => createConversation()} className="rounded-lg border border-border p-2 hover:bg-muted" title="Nova conversa">
          <IconPlus className="h-4 w-4" />
        </button>
      </div>
      <div className="mb-3">
        <select value={materialId} onChange={(e) => setMaterialId(e.target.value)} className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm">
          <option value="">Sem material específico</option>
          {materials.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}
        </select>
      </div>
      <div className="flex-1 overflow-y-auto rounded-xl border border-border bg-card p-4 space-y-4">
        {(!conv || conv.messages.length === 0) && (
          <div className="text-center text-muted-foreground py-12 text-sm">
            <IconBot className="mx-auto h-10 w-10 mb-3 opacity-50" />
            <p>Olá! Sou o Professor IA.</p>
            <p className="mt-1">Pergunte sobre seus materiais, peça explicações ou dicas de estudo.</p>
          </div>
        )}
        {conv?.messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
              {m.content}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div className="mt-3 flex gap-2">
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()} placeholder="Digite sua pergunta..." className="flex-1 rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary" />
        <button onClick={handleSend} disabled={!input.trim()} className="rounded-xl bg-primary px-4 text-primary-foreground disabled:opacity-50">
          <IconSend className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
