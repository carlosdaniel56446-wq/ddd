"use client";

import type { DragEvent } from "react";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { IconUpload, IconFile, IconX, IconCheck } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";

export default function UploadPage() {
  const router = useRouter();
  const { addMaterial } = useAppStore();
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [dragging, setDragging] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleTextSubmit = () => {
    if (!text.trim()) {
      setError("Cole ou digite o conteúdo do material.");
      return;
    }
    setLoading(true);
    setError("");
    addMaterial({
      title: title.trim() || "Texto colado",
      originalText: text.trim(),
      fileType: "text",
    });
    setSuccess(true);
    setTimeout(() => router.push("/materiais"), 800);
  };

  const readFile = useCallback(
    async (file: File) => {
      setError("");
      setLoading(true);
      const maxSize = 8 * 1024 * 1024;
      if (file.size > maxSize) {
        setError("Arquivo muito grande. Máximo 8 MB.");
        setLoading(false);
        return;
      }
      const name = file.name;
      const type = file.type;
      try {
        if (type === "text/plain" || name.endsWith(".txt") || name.endsWith(".md")) {
          const content = await file.text();
          addMaterial({
            title: title.trim() || name,
            originalText: content,
            fileName: name,
            fileType: "text",
          });
          setSuccess(true);
          setTimeout(() => router.push("/materiais"), 800);
          return;
        }
        if (type === "application/pdf" || name.endsWith(".pdf")) {
          setError("PDF detectado. Por enquanto, copie o texto do PDF e cole no campo abaixo.");
          setLoading(false);
          return;
        }
        if (type.startsWith("image/")) {
          setError("Imagem recebida. Digite ou cole o texto das anotações para melhor resultado.");
          setLoading(false);
          return;
        }
        setError("Formato não suportado. Use .txt ou cole o texto.");
        setLoading(false);
      } catch {
        setError("Não foi possível ler o arquivo. Tente colar o texto.");
        setLoading(false);
      }
    },
    [addMaterial, router, title]
  );

  const onDrop = useCallback(
    (e: DragEvent) => {
      e.preventDefault();
      setDragging(false);
      const file = e.dataTransfer.files[0];
      if (file) readFile(file);
    },
    [readFile]
  );

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Enviar material</h1>
        <p className="text-muted-foreground mt-1">
          Cole um texto, envie um arquivo .txt ou arraste arquivos.
        </p>
      </div>

      <div>
        <label className="text-sm font-medium mb-1.5 block">Título (opcional)</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Ex: Equações do 2º grau — Aula 3"
          className="w-full rounded-lg border border-border bg-card px-4 py-2.5 outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`rounded-2xl border-2 border-dashed p-8 text-center transition ${
          dragging ? "border-primary bg-primary/5" : "border-border bg-card hover:border-primary/40"
        }`}
      >
        <IconUpload className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
        <p className="font-medium">Arraste arquivos aqui</p>
        <p className="text-sm text-muted-foreground mt-1">.txt, .md (PDF: cole o texto)</p>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="mt-4 inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm font-medium hover:bg-muted"
        >
          <IconFile className="h-4 w-4" />
          Escolher arquivo
        </button>
        <input
          ref={fileRef}
          type="file"
          accept=".txt,.md,text/plain,application/pdf,image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) readFile(f);
          }}
        />
      </div>

      <div>
        <label className="text-sm font-medium mb-1.5 block">Ou cole o texto do material</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Cole aqui o conteúdo da aula, anotações, capítulos..."
          rows={10}
          className="w-full rounded-xl border border-border bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-primary resize-y text-sm leading-relaxed"
        />
        <p className="text-xs text-muted-foreground mt-1">
          {text.length.toLocaleString("pt-BR")} caracteres
        </p>
      </div>

      {error && (
        <div className="rounded-lg bg-destructive/10 text-destructive px-4 py-3 text-sm">{error}</div>
      )}
      {success && (
        <div className="rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 px-4 py-3 text-sm flex items-center gap-2">
          <IconCheck className="h-4 w-4" /> Material enviado! Analisando...
        </div>
      )}

      <button
        onClick={handleTextSubmit}
        disabled={loading || !text.trim()}
        className="w-full rounded-xl bg-primary py-3.5 font-semibold text-primary-foreground disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {loading ? "Processando..." : (
          <><IconUpload className="h-5 w-5" /> Enviar e analisar</>
        )}
      </button>
    </div>
  );
}
