"use client";

import { useState } from "react";
import { IconCalendar, IconPlus, IconCheck } from "@/components/Icons";
import { useAppStore } from "@/store/AppContext";
import { generateId } from "@/lib/utils";
import type { StudyPlan, StudyPlanSession } from "@/types";

export default function PlanoPage() {
  const { plans, addPlan, updatePlan, materials } = useAppStore();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [dailyMinutes, setDailyMinutes] = useState(60);
  const [examDate, setExamDate] = useState("");

  const createPlan = () => {
    if (!title.trim()) return;
    const sessions: StudyPlanSession[] = [];
    const start = new Date();
    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(d.getDate() + i);
      sessions.push({
        id: generateId(),
        date: d.toISOString().slice(0, 10),
        title: i % 2 === 0 ? "Estudo de conteúdo" : "Exercícios e revisão",
        type: i % 2 === 0 ? "estudo" : "exercicio",
        durationMinutes: Math.min(dailyMinutes, 90),
        completed: false,
        postponed: false,
        materialId: materials[0]?.id,
      });
    }
    const plan: StudyPlan = {
      id: generateId(),
      title: title.trim(),
      examDate: examDate || undefined,
      dailyMinutes,
      subjects: materials.map((m) => m.subject || m.title).filter(Boolean) as string[],
      sessions,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addPlan(plan);
    setShowForm(false);
    setTitle("");
  };

  const toggleSession = (planId: string, sessionId: string) => {
    const plan = plans.find((p) => p.id === planId);
    if (!plan) return;
    updatePlan(planId, {
      sessions: plan.sessions.map((s) => s.id === sessionId ? { ...s, completed: !s.completed } : s),
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Plano de estudos</h1>
          <p className="text-sm text-muted-foreground">Recomendações ajustáveis</p>
        </div>
        <button onClick={() => setShowForm(true)} className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground flex items-center gap-1">
          <IconPlus className="h-4 w-4" /> Novo plano
        </button>
      </div>
      {showForm && (
        <div className="rounded-xl border border-border bg-card p-5 space-y-3">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Nome do plano" className="w-full rounded-lg border border-border px-3 py-2" />
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="text-xs text-muted-foreground">Minutos/dia</label>
              <input type="number" value={dailyMinutes} onChange={(e) => setDailyMinutes(Number(e.target.value) || 30)} min={15} max={480} className="w-full rounded-lg border border-border px-3 py-2" />
            </div>
            <div className="flex-1">
              <label className="text-xs text-muted-foreground">Data da prova (opcional)</label>
              <input type="date" value={examDate} onChange={(e) => setExamDate(e.target.value)} className="w-full rounded-lg border border-border px-3 py-2" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={createPlan} className="rounded-lg bg-primary px-4 py-2 text-sm text-primary-foreground">Criar</button>
            <button onClick={() => setShowForm(false)} className="rounded-lg border px-4 py-2 text-sm">Cancelar</button>
          </div>
        </div>
      )}
      {plans.length === 0 && !showForm && (
        <div className="text-center py-12 text-muted-foreground">
          <IconCalendar className="mx-auto h-12 w-12 mb-3 opacity-50" />
          <p>Nenhum plano ainda. Crie um para organizar seus estudos.</p>
        </div>
      )}
      {plans.map((plan) => (
        <div key={plan.id} className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-semibold">{plan.title}</h2>
          <p className="text-xs text-muted-foreground mb-3">
            {plan.dailyMinutes} min/dia{plan.examDate && ` · Prova: ${plan.examDate}`}
          </p>
          <div className="space-y-2">
            {plan.sessions.map((s) => (
              <button key={s.id} onClick={() => toggleSession(plan.id, s.id)} className={`w-full flex items-center gap-3 rounded-lg border p-3 text-left text-sm ${s.completed ? "border-emerald-500/40 bg-emerald-500/5" : "border-border"}`}>
                <div className={`h-5 w-5 rounded-full border flex items-center justify-center shrink-0 ${s.completed ? "bg-emerald-500 border-emerald-500 text-white" : "border-muted-foreground"}`}>
                  {s.completed && <IconCheck className="h-3 w-3" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className={s.completed ? "line-through text-muted-foreground" : ""}>{s.title}</p>
                  <p className="text-xs text-muted-foreground">{s.date} · {s.durationMinutes} min · {s.type}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
