"use client";

import type { ReactNode } from "react";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  IconHome, IconBook, IconLibrary, IconFile, IconLayers,
  IconHelp, IconClipboard, IconCalendar, IconBot, IconChart,
  IconSettings, IconMenu, IconX, IconUpload, IconMoon, IconSun,
} from "./Icons";
import { useAppStore } from "@/store/AppContext";
import { cn } from "@/lib/utils";
import { Onboarding } from "./Onboarding";
import { AppProvider } from "@/store/AppContext";

const NAV = [
  { href: "/", label: "Início", icon: IconHome },
  { href: "/materiais", label: "Meus materiais", icon: IconBook },
  { href: "/biblioteca", label: "Biblioteca", icon: IconLibrary },
  { href: "/resumos", label: "Resumos", icon: IconFile },
  { href: "/flashcards", label: "Flashcards", icon: IconLayers },
  { href: "/exercicios", label: "Exercícios", icon: IconHelp },
  { href: "/simulados", label: "Simulados", icon: IconClipboard },
  { href: "/plano", label: "Plano de estudos", icon: IconCalendar },
  { href: "/professor", label: "Professor IA", icon: IconBot },
  { href: "/progresso", label: "Meu progresso", icon: IconChart },
  { href: "/configuracoes", label: "Configurações", icon: IconSettings },
];

function ShellInner({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { isOnboarded, user, updateUser, ready } = useAppStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const stored = localStorage.getItem("pf-theme");
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    const isDark = stored === "dark" || (!stored && prefersDark);
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("pf-theme", next ? "dark" : "light");
    updateUser({ theme: next ? "dark" : "light" });
  };

  if (!mounted || !ready) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!isOnboarded) {
    return <Onboarding />;
  }

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-r border-border bg-card">
        <div className="flex h-16 items-center gap-2 px-5 border-b border-border">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-lg">
            P
          </div>
          <div>
            <p className="font-semibold text-foreground leading-tight">Passa Fácil</p>
            <p className="text-xs text-muted-foreground">Estude com IA</p>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border">
          <Link
            href="/upload"
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90 transition"
          >
            <IconUpload className="h-4 w-4" />
            Enviar material
          </Link>
        </div>
      </aside>

      <div className="lg:hidden fixed top-0 inset-x-0 z-40 flex h-14 items-center justify-between border-b border-border bg-card px-4">
        <button onClick={() => setMobileOpen(true)} className="p-2 rounded-lg hover:bg-muted" aria-label="Menu">
          <IconMenu className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm">P</div>
          <span className="font-semibold">Passa Fácil</span>
        </div>
        <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-muted" aria-label="Tema">
          {dark ? <IconSun className="h-5 w-5" /> : <IconMoon className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 bg-card shadow-xl flex flex-col">
            <div className="flex h-14 items-center justify-between px-4 border-b border-border">
              <span className="font-semibold">Menu</span>
              <button onClick={() => setMobileOpen(false)} className="p-2"><IconX className="h-5 w-5" /></button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
              {NAV.map((item) => {
                const active = pathname === item.href;
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium",
                      active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            <div className="p-3 border-t border-border">
              <Link href="/upload" onClick={() => setMobileOpen(false)} className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground">
                <IconUpload className="h-4 w-4" /> Enviar material
              </Link>
            </div>
          </div>
        </div>
      )}

      <main className="flex-1 lg:pl-64">
        <div className="lg:hidden h-14" />
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="hidden lg:flex items-center justify-between mb-6">
            <p className="text-sm text-muted-foreground">
              Olá, <span className="font-medium text-foreground">{user?.name || "Estudante"}</span>
            </p>
            <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-muted border border-border" aria-label="Tema">
              {dark ? <IconSun className="h-4 w-4" /> : <IconMoon className="h-4 w-4" />}
            </button>
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <AppProvider>
      <ShellInner>{children}</ShellInner>
    </AppProvider>
  );
}
