"use client";

import { useState } from "react";
import { useAppStore } from "@/store/AppContext";
import type { StudyProfile } from "@/types";

const PROFILES: { id: StudyProfile; label: string; desc: string; emoji: string }[] = [
  { id: "fundamental", label: "Ensino Fundamental", desc: "Linguagem simples e didática", emoji: "📚" },
  { id: "medio", label: "Ensino Médio", desc: "Base sólida para o futuro", emoji: "🎓" },
  { id: "enem", label: "ENEM e Vestibulares", desc: "Foco em provas e revisão", emoji: "🏆" },
  { id: "superior", label: "Ensino Superior", desc: "Conteúdo mais aprofundado", emoji: "🏛️" },
  { id: "tecnico", label: "Curso Técnico", desc: "Prático e profissionalizante", emoji: "🔧" },
  { id: "concurso", label: "Concursos", desc: "Preparação objetiva", emoji: "💼" },
  { id: "outro", label: "Outro", desc: "Perfil personalizado", emoji: "✨" },
];

export function Onboarding() {
  const { completeOnboarding } = useAppStore();
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [profile, setProfile] = useState<StudyProfile | null>(null);

  const handleFinish = () => {
    if (!name.trim() || !profile) return;
    completeOnboarding(name.trim(), profile);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-lg animate-fade-in">
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground font-bold text-2xl mb-4">
            P
          </div>
          <h1 className="text-2xl font-bold text-foreground">Passa Fácil</h1>
          <p className="text-muted-foreground mt-1">
            Envie seu material. A IA organiza seus estudos.
          </p>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm">
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">Como podemos te chamar?</h2>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome ou apelido"
                className="w-full rounded-lg border border-border bg-background px-4 py-3 text-foreground outline-none focus:ring-2 focus:ring-primary"
                autoFocus
                maxLength={40}
              />
              <button
                onClick={() => name.trim() && setStep(2)}
                disabled={!name.trim()}
                className="w-full rounded-lg bg-primary py-3 font-medium text-primary-foreground disabled:opacity-50"
              >
                Continuar
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">Qual o seu perfil de estudo?</h2>
              <p className="text-sm text-muted-foreground">
                Isso ajuda a ajustar a linguagem e a profundidade das explicações.
              </p>
              <div className="grid gap-2">
                {PROFILES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setProfile(p.id)}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition ${
                      profile === p.id
                        ? "border-primary bg-primary/10"
                        : "border-border hover:bg-muted"
                    }`}
                  >
                    <span className="text-xl">{p.emoji}</span>
                    <div>
                      <p className="font-medium text-sm">{p.label}</p>
                      <p className="text-xs text-muted-foreground">{p.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 rounded-lg border border-border py-3 font-medium"
                >
                  Voltar
                </button>
                <button
                  onClick={handleFinish}
                  disabled={!profile}
                  className="flex-1 rounded-lg bg-primary py-3 font-medium text-primary-foreground disabled:opacity-50"
                >
                  Começar a estudar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
