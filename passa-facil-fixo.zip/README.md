# Passa Fácil — Plataforma Inteligente de Estudos com IA

Envie seu material. A IA organiza seus estudos e prepara o que você precisa para aprender.

## Funcionalidades (MVP)

- **Envio de materiais**: cole texto ou envie .txt/.md
- **Análise inteligente local**: detecção de matéria, tópicos, conceitos, fórmulas e definições
- **Pacote de estudo automático**: resumo, flashcards e questões
- **Flashcards** com marcação de dificuldade e revisão
- **Exercícios** com correção automática
- **Simulados** práticos
- **Professor IA** conversacional (baseado no material)
- **Plano de estudos** semanal
- **Progresso** real baseado no uso
- **Modo claro/escuro**
- **Persistência** via localStorage (dados no navegador)
- **Responsivo** (mobile + desktop)
- Interface 100% em português brasileiro

## Como rodar

```bash
cd passa-facil
npm install
npm run dev
```

Abra http://localhost:3000

## Deploy na Vercel

1. Faça push do repositório para o GitHub
2. Importe o projeto em [vercel.com](https://vercel.com)
3. Deploy automático (Next.js detectado)

Ou:

```bash
npx vercel
```

## Arquitetura

- **Next.js 16** (App Router) + TypeScript + Tailwind CSS 4
- Estado: Zustand + persist (localStorage)
- IA local: heurísticas + extração de padrões (sem chave de API necessária no MVP)
- Pronto para evoluir com API de LLM (xAI / OpenAI) no backend

## Limitações atuais

- Extração de PDF/imagem: cole o texto (OCR/PDF.js pode ser adicionado)
- IA generativa completa requer chave de API externa
- Dados apenas no navegador (sem sync entre dispositivos)

## Próximos passos

- Integração com xAI Grok API ou OpenAI
- PDF.js + Tesseract.js para extração real
- Autenticação e backend (Supabase / Vercel Postgres)
- Revisão espaçada avançada
